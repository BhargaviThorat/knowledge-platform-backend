package com.mindbowser.knowledgeplatform.controller;

import com.mindbowser.knowledgeplatform.dto.ArticleRequest;
import com.mindbowser.knowledgeplatform.dto.ArticleResponse;
import com.mindbowser.knowledgeplatform.service.ArticleService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/articles")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:5173")
public class ArticleController {

    private final ArticleService articleService;

    // ─── CREATE (auth required) ───────────────────────────────────────
    @PostMapping
    public ResponseEntity<ArticleResponse> createArticle(
            @Valid @RequestBody ArticleRequest request,
            Authentication authentication) {

        String email = authentication.getName();
        ArticleResponse response = articleService.createArticle(request, email);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);

    }

    // ─── GET ALL (public) ─────────────────────────────────────────────
    @GetMapping
    public ResponseEntity<List<ArticleResponse>> getAllArticles() {
        return ResponseEntity.ok(articleService.getAllArticles());
    }

    // ─── GET SINGLE (public) ──────────────────────────────────────────
    @GetMapping("/{id}")
    public ResponseEntity<ArticleResponse> getArticleById(@PathVariable Long id) {
        return ResponseEntity.ok(articleService.getArticleById(id));
    }

    // ─── UPDATE (auth + author check) ────────────────────────────────
    @PutMapping("/{id}")
    public ResponseEntity<ArticleResponse> updateArticle(
            @PathVariable Long id,
            @Valid @RequestBody ArticleRequest request,
            Authentication authentication) {

        String email = authentication.getName();
        return ResponseEntity.ok(articleService.updateArticle(id, request, email));
    }

    // ─── DELETE (auth + author check) ────────────────────────────────
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteArticle(
            @PathVariable Long id,
            Authentication authentication) {

        String email = authentication.getName();
        articleService.deleteArticle(id, email);
        return ResponseEntity.noContent().build();
    }

    // ─── MY ARTICLES (auth required) ─────────────────────────────────
    @GetMapping("/my")
    public ResponseEntity<List<ArticleResponse>> getMyArticles(
            Authentication authentication) {

        String email = authentication.getName();
        return ResponseEntity.ok(articleService.getMyArticles(email));
    }

    // ─── SEARCH + FILTER (public) ─────────────────────────────────────
    @GetMapping("/search")
    public ResponseEntity<List<ArticleResponse>> searchArticles(
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String category) {

        return ResponseEntity.ok(articleService.searchArticles(keyword, category));
    }
}
