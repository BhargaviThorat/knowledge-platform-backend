package com.mindbowser.knowledgeplatform.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AuthResponse {

    private Long id;          // ← ADDED (frontend needs this!)
    private String token;
    private String username;
    private String email;
}
