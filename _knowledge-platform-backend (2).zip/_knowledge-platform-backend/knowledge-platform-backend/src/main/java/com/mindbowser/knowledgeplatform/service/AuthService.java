package com.mindbowser.knowledgeplatform.service;

import com.mindbowser.knowledgeplatform.dto.AuthResponse;
import com.mindbowser.knowledgeplatform.dto.LoginRequest;
import com.mindbowser.knowledgeplatform.dto.SignupRequest;

public interface AuthService {
    AuthResponse signup(SignupRequest request);
    AuthResponse login(LoginRequest request);
    AuthResponse getCurrentUser(String email);  // ← ADDED
}
