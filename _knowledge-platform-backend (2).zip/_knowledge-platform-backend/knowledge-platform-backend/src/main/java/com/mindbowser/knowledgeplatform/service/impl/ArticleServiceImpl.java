package com.mindbowser.knowledgeplatform.service.impl;

import com.mindbowser.knowledgeplatform.dto.ArticleRequest;
import com.mindbowser.knowledgeplatform.dto.ArticleResponse;
import com.mindbowser.knowledgeplatform.entity.Article;
import com.mindbowser.knowledgeplatform.entity.User;
import com.mindbowser.knowledgeplatform.repository.ArticleRepository;
import com.mindbowser.knowledgeplatform.repository.UserRepository;
import com.mindbowser.knowledgeplatform.service.ArticleService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ArticleServiceImpl implements ArticleService {

    private final ArticleRepository articleRepository;
    private final UserRepository userRepository;

    // ─── Helper: Entity → Response DTO ───────────────────────────────
    private ArticleResponse mapToResponse(Article article) {
        return ArticleResponse.builder()
                .id(article.getId())
                .title(article.getTitle())
                .content(article.getContent())
                .summary(article.getSummary())
                .category(article.getCategory())
                .tags(article.getTags())
                .coverImageUrl(article.getCoverImageUrl())   // ← ADDED
                .authorId(article.getAuthor().getId())
                .authorName(article.getAuthor().getUsername())
                .createdAt(article.getCreatedAt())
                .updatedAt(article.getUpdatedAt())
                .build();
    }

    // ─── Helper: get User by email ────────────────────────────────────
    private User getUserByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));
    }

    // ─── Helper: get Article by id ────────────────────────────────────
    private Article getArticleById_internal(Long id) {
        return articleRepository.findById(id)
                .orElseThrow(() -> new RuntimeException(
                        "Article not found with id: " + id));
    }

    // ─── Helper: AUTHOR CHECK ─────────────────────────────────────────
    private void verifyAuthor(Article article, String requestingUserEmail) {
        if (!article.getAuthor().getEmail().equals(requestingUserEmail)) {
            throw new AccessDeniedException(
                    "You are not authorized to modify this article"
            );
        }
    }

    // ─── CREATE ───────────────────────────────────────────────────────
    @Override
    public ArticleResponse createArticle(ArticleRequest request, String authorEmail) {
        User author = getUserByEmail(authorEmail);

        Article article = Article.builder()
                .title(request.getTitle())
                .content(request.getContent())
                .summary(request.getSummary())
                .category(request.getCategory())
                .tags(request.getTags())
                .coverImageUrl(request.getCoverImageUrl())   // ← ADDED
                .author(author)
                .build();

        return mapToResponse(articleRepository.save(article));
    }

    // ─── GET SINGLE ───────────────────────────────────────────────────
    @Override
    public ArticleResponse getArticleById(Long id) {
        return mapToResponse(getArticleById_internal(id));
    }

    // ─── GET ALL ──────────────────────────────────────────────────────
    @Override
    public List<ArticleResponse> getAllArticles() {
        return articleRepository.findAll()
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    // ─── UPDATE ───────────────────────────────────────────────────────
    @Override
    public ArticleResponse updateArticle(Long id, ArticleRequest request,
                                          String authorEmail) {
        Article article = getArticleById_internal(id);
        verifyAuthor(article, authorEmail);

        article.setTitle(request.getTitle());
        article.setContent(request.getContent());
        article.setSummary(request.getSummary());
        article.setCategory(request.getCategory());
        article.setTags(request.getTags());
        article.setCoverImageUrl(request.getCoverImageUrl());   // ← ADDED

        return mapToResponse(articleRepository.save(article));
    }

    // ─── DELETE ───────────────────────────────────────────────────────
    @Override
    public void deleteArticle(Long id, String authorEmail) {
        Article article = getArticleById_internal(id);
        verifyAuthor(article, authorEmail);
        articleRepository.delete(article);
    }

    // ─── MY ARTICLES ──────────────────────────────────────────────────
    @Override
    public List<ArticleResponse> getMyArticles(String authorEmail) {
        User author = getUserByEmail(authorEmail);
        return articleRepository.findByAuthorId(author.getId())
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    // ─── SEARCH + FILTER ──────────────────────────────────────────────
    @Override
    public List<ArticleResponse> searchArticles(String keyword, String category) {
        List<Article> results;

        if (keyword != null && !keyword.isEmpty()) {
            results = articleRepository.searchArticlesWithCategory(keyword, category);
        } else if (category != null && !category.isEmpty()) {
            results = articleRepository.findByCategory(category);
        } else {
            results = articleRepository.findAll();
        }

        return results.stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }
}
