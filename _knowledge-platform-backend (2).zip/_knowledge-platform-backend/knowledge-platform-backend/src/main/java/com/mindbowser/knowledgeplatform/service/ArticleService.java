package com.mindbowser.knowledgeplatform.service;

import com.mindbowser.knowledgeplatform.dto.ArticleRequest;
import com.mindbowser.knowledgeplatform.dto.ArticleResponse;

import java.util.List;

public interface ArticleService {

    ArticleResponse createArticle(ArticleRequest request, String authorEmail);

    ArticleResponse getArticleById(Long id);

    List<ArticleResponse> getAllArticles();

    ArticleResponse updateArticle(Long id, ArticleRequest request, String authorEmail);

    void deleteArticle(Long id, String authorEmail);

    List<ArticleResponse> getMyArticles(String authorEmail);

    List<ArticleResponse> searchArticles(String keyword, String category);
}
