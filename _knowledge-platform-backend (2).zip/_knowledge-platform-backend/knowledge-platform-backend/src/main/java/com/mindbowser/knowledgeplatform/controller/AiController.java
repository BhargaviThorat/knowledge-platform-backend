package com.mindbowser.knowledgeplatform.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.mindbowser.knowledgeplatform.dto.AiRequest;
import com.mindbowser.knowledgeplatform.dto.AiResponse;

import java.util.Map;

@RestController
@RequestMapping("/api/ai")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:5173")
public class AiController {

    @PostMapping("/improve")
    public ResponseEntity<Map<String, String>> improveContent(
            @RequestBody AiRequest request) {
        String original = request.getContent();
        String improved = "✨ [AI Improved]: " + original.trim()
                + " This content has been professionally refined "
                + "for clarity, conciseness, and better readability.";
        return ResponseEntity.ok(Map.of("improved", improved));
    }

    @PostMapping("/summarize")
    public ResponseEntity<AiResponse> summarize(@RequestBody AiRequest request) {

        String content = request.getContent();

        if (content == null || content.isEmpty()) {
            return ResponseEntity.ok(new AiResponse("No content provided."));
        }

        String[] sentences = content.split("\\. ");

        StringBuilder summary = new StringBuilder();

        // Take first 4–5 sentences instead of 1 line
        for (int i = 0; i < Math.min(5, sentences.length); i++) {
            summary.append(sentences[i]).append(". ");
        }

        summary.append("\n\nThis summary highlights the key concepts and core ideas discussed in the article, focusing on the most important technical aspects.");

        return ResponseEntity.ok(new AiResponse(summary.toString()));
    }

    @PostMapping("/suggest-tags")
    public ResponseEntity<Map<String, String>> suggestTags(
            @RequestBody AiRequest request) {
        String content = request.getContent().toLowerCase();
        StringBuilder tags = new StringBuilder();

        if (content.contains("java") || content.contains("spring"))
            tags.append("java,spring,");
        if (content.contains("react") || content.contains("frontend"))
            tags.append("react,frontend,");
        if (content.contains("database") || content.contains("sql")
                || content.contains("mysql"))
            tags.append("database,sql,");
        if (content.contains("api") || content.contains("rest"))
            tags.append("api,rest,");
        if (content.contains("docker") || content.contains("devops"))
            tags.append("docker,devops,");

        String result = tags.length() > 0
                ? tags.substring(0, tags.length() - 1)
                : "general,programming,tech";
        return ResponseEntity.ok(Map.of("tags", result));
    }

    @PostMapping("/suggest-title")
    public ResponseEntity<Map<String, String>> suggestTitle(
            @RequestBody AiRequest request) {
        String content = request.getContent();
        String title = "💡 " + content
                .substring(0, Math.min(50, content.length()))
                .trim() + " — A Complete Guide";
        return ResponseEntity.ok(Map.of("title", title));
    }
}
