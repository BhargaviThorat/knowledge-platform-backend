package com.mindbowser.knowledgeplatform.repository;

import com.mindbowser.knowledgeplatform.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByEmail(String email);

    boolean existsByEmail(String email);

    boolean existsByUsername(String username);
}


/* 
 * 
 * existsByEmail and existsByUsername will be used during Signup to 
 * prevent duplicate registrations — Spring Data JPA generates these 
 * queries automatically just from the method name. No SQL needed!
 * */
 