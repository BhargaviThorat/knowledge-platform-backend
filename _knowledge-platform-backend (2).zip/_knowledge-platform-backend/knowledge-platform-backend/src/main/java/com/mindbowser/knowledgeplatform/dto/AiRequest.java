package com.mindbowser.knowledgeplatform.dto;

import lombok.Data;

@Data
public class AiRequest {
    private String content;
}
