package com.mindbowser.knowledgeplatform.repository;

import com.mindbowser.knowledgeplatform.entity.Article;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ArticleRepository extends JpaRepository<Article, Long> {

    // Get all articles by a specific author
    List<Article> findByAuthorId(Long authorId);

    // Filter by category
    List<Article> findByCategory(String category);

    // Search by title OR content OR tags containing keyword
    @Query("SELECT a FROM Article a WHERE " +
           "LOWER(a.title) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(a.content) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(a.tags) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    List<Article> searchArticles(@Param("keyword") String keyword);

    // Search with category filter combined
    @Query("SELECT a FROM Article a WHERE " +
           "(LOWER(a.title) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(a.content) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(a.tags) LIKE LOWER(CONCAT('%', :keyword, '%'))) " +
           "AND (:category IS NULL OR a.category = :category)")
    List<Article> searchArticlesWithCategory(
            @Param("keyword") String keyword,
            @Param("category") String category);
}
