import { useState, useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import API from '../api/axios'
import { useAuth } from '../context/AuthContext'
import './Dashboard.css'

const CATEGORY_COLORS = {
  Tech:     { bg: '#dbeafe', color: '#1d4ed8' },
  AI:       { bg: '#ede9fe', color: '#7c3aed' },
  Backend:  { bg: '#dcfce7', color: '#16a34a' },
  Frontend: { bg: '#ffedd5', color: '#ea580c' },
  DevOps:   { bg: '#fef9c3', color: '#ca8a04' },
  Other:    { bg: '#f1f5f9', color: '#475569' },
}

const Dashboard = () => {
  const { user } = useAuth()
  const navigate = useNavigate()

  const [articles, setArticles] = useState([])
  const [loading, setLoading] = useState(true)
  const [deletingId, setDeletingId] = useState(null)

  useEffect(() => {
    if (!user) { navigate('/login'); return }
    fetchMyArticles()
  }, [])

  const fetchMyArticles = async () => {
    try {
      const res = await API.get('/articles/my')
      setArticles(res.data)
    } catch (err) {
      console.error('Failed to fetch articles', err)
    } finally {
      setLoading(false)
    }
  }

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this article? This cannot be undone.')) return
    setDeletingId(id)
    try {
      await API.delete(`/articles/${id}`)
      setArticles(articles.filter(a => a.id !== id))
    } catch (err) {
      alert('Failed to delete article')
    } finally {
      setDeletingId(null)
    }
  }

  return (
    <div className="dashboard-page">
      <div className="container">

        {/* ── HEADER ── */}
        <div className="dashboard-header">
          <div>
            <h1>📊 My Dashboard</h1>
            <p>Welcome back, <strong>{user?.username}</strong>! Manage your articles here.</p>
          </div>
          <Link to="/create" className="dashboard-new-btn">
            ✍️ New Article
          </Link>
        </div>

        {/* ── STATS ROW ── */}
        <div className="stats-row">
          <div className="stat-card">
            <span className="stat-icon">📝</span>
            <div>
              <span className="stat-number">{articles.length}</span>
              <span className="stat-label">Total Articles</span>
            </div>
          </div>
          <div className="stat-card">
            <span className="stat-icon">🗂️</span>
            <div>
              <span className="stat-number">
                {new Set(articles.map(a => a.category)).size}
              </span>
              <span className="stat-label">Categories</span>
            </div>
          </div>
          <div className="stat-card">
            <span className="stat-icon">🏷️</span>
            <div>
              <span className="stat-number">
                {articles.reduce((acc, a) =>
                  acc + (a.tags ? a.tags.split(',').length : 0), 0
                )}
              </span>
              <span className="stat-label">Total Tags</span>
            </div>
          </div>
          <div className="stat-card">
            <span className="stat-icon">📅</span>
            <div>
              <span className="stat-number">
                {articles.length > 0
                  ? new Date(articles[0].createdAt).toLocaleDateString('en-IN', { month: 'short', day: 'numeric' })
                  : '—'}
              </span>
              <span className="stat-label">Latest Article</span>
            </div>
          </div>
        </div>

        {/* ── ARTICLES TABLE ── */}
        <div className="dashboard-table-section">
          <h2>Your Articles</h2>

          {loading ? (
            <div className="dashboard-loading">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="dashboard-skeleton" />
              ))}
            </div>
          ) : articles.length === 0 ? (
            <div className="dashboard-empty">
              <div className="empty-icon">📭</div>
              <h3>No articles yet!</h3>
              <p>Start sharing your knowledge with the community.</p>
              <Link to="/create" className="dashboard-new-btn">
                ✍️ Write Your First Article
              </Link>
            </div>
          ) : (
            <div className="dashboard-table-wrapper">
              <table className="dashboard-table">
                <thead>
                  <tr>
                    <th>Title</th>
                    <th>Category</th>
                    <th>Tags</th>
                    <th>Published</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {articles.map(article => {
                    const catStyle = CATEGORY_COLORS[article.category] || CATEGORY_COLORS['Other']
                    return (
                      <tr key={article.id}>
                        <td>
                          <Link
                            to={`/articles/${article.id}`}
                            className="table-article-title"
                          >
                            {article.title}
                          </Link>
                          <p className="table-article-summary">
                            {article.content?.replace(/<[^>]+>/g, '').slice(0, 80)}...
                          </p>
                        </td>
                        <td>
                          <span
                            className="table-category"
                            style={{ backgroundColor: catStyle.bg, color: catStyle.color }}
                          >
                            {article.category}
                          </span>
                        </td>
                        <td>
                          <div className="table-tags">
                            {article.tags?.split(',').slice(0, 2).map(tag => (
                              <span key={tag} className="table-tag">#{tag.trim()}</span>
                            ))}
                          </div>
                        </td>
                        <td className="table-date">
                          {new Date(article.createdAt).toLocaleDateString('en-IN', {
                            day: 'numeric', month: 'short', year: 'numeric'
                          })}
                        </td>
                        <td>
                          <div className="table-actions">
                            <Link
                              to={`/articles/${article.id}`}
                              className="tbl-btn tbl-btn-view"
                            >
                              👁️ View
                            </Link>
                            <Link
                              to={`/edit/${article.id}`}
                              className="tbl-btn tbl-btn-edit"
                            >
                              ✏️ Edit
                            </Link>
                            <button
                              className="tbl-btn tbl-btn-delete"
                              onClick={() => handleDelete(article.id)}
                              disabled={deletingId === article.id}
                            >
                              {deletingId === article.id ? '⏳' : '🗑️'} Delete
                            </button>
                          </div>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>

      </div>
    </div>
  )
}

export default Dashboard
