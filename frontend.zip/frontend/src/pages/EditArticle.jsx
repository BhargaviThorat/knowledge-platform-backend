import { useState, useEffect } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import ReactQuill from "react-quill-new";
import "react-quill-new/dist/quill.snow.css";
import API from '../api/axios'
import { useAuth } from '../context/AuthContext'

const CATEGORIES = ['Tech', 'AI', 'Backend', 'Frontend', 'DevOps', 'Other']

const modules = {
  toolbar: [
    [{ header: [1, 2, 3, false] }],
    ['bold', 'italic', 'underline', 'strike'],
    [{ list: 'ordered' }, { list: 'bullet' }],
    ['blockquote', 'code-block'],
    ['link', 'image'],
    ['clean'],
  ],
}

const EditArticle = () => {
  const { id } = useParams()
  const { user } = useAuth()
  const navigate = useNavigate()

  const [formData, setFormData] = useState({
    title: '',
    category: 'Tech',
    tags: '',
    content: '',
    coverImageUrl: '',
  })

  const [loading, setLoading] = useState(false)
  const [fetching, setFetching] = useState(true)
  const [error, setError] = useState('')

  const [aiLoading, setAiLoading] = useState({
    improve: false,
    summarize: false,
    title: false,
    tags: false,
  })

  const [aiResult, setAiResult] = useState('')
  const [aiResultType, setAiResultType] = useState('')

  useEffect(() => {
    if (!user) { navigate('/login'); return }
    fetchArticle()
  }, [id])

  const fetchArticle = async () => {
    try {
      const res = await API.get(`/articles/${id}`)
      const a = res.data
      if (user && a.authorId !== user.id) {
        navigate('/')
        return
      }
      setFormData({
        title: a.title || '',
        category: a.category || 'Tech',
        tags: a.tags || '',
        content: a.content || '',
        coverImageUrl: a.coverImageUrl || '',
      })
    } catch {
      setError('Failed to load article')
    } finally {
      setFetching(false)
    }
  }

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value })
  }

  const handleContentChange = (value) => {
    setFormData({ ...formData, content: value })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!formData.title.trim()) { setError('Title is required'); return }
    if (!formData.content.trim() || formData.content === '<p><br></p>') {
      setError('Content is required'); return
    }

    setLoading(true)
    setError('')
    try {
      await API.put(`/articles/${id}`, formData)
      navigate(`/articles/${id}`)
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to update article')
    } finally {
      setLoading(false)
    }
  }

  const isAnyAiLoading = Object.values(aiLoading).some(Boolean)

  if (fetching) {
    return (
      <div style={{ textAlign: 'center', padding: '80px', color: '#666' }}>
        ⏳ Loading article...
      </div>
    )
  }

  return (
    <div style={{
      width: "100%",
      minHeight: "100vh",
      overflowX: "hidden",
      padding: "40px 0 80px",
      boxSizing: "border-box"
    }}>

      <div style={{
        width: "100%",
        maxWidth: "1200px",
        margin: "0 auto",
        padding: "0 20px",
        boxSizing: "border-box"
      }}>

        {/* HEADER */}
        <div style={{ marginBottom: "32px" }}>
          <h1 style={{ fontSize: "2rem", fontWeight: 800, marginBottom: "6px" }}>
            ✏️ Edit Article
          </h1>
          <p style={{ color: "#666" }}>
            Update your article and republish
          </p>
        </div>

        {/* GRID LAYOUT */}
        <div style={{
          display: "grid",
          gridTemplateColumns: "minmax(0,1fr) 340px",
          gap: "40px",
          width: "100%"
        }}>

          {/* LEFT SIDE */}
          <div style={{ width: "100%" }}>

            {error && (
              <div style={{
                background: "#fef2f2",
                border: "1px solid #fecaca",
                color: "#dc2626",
                padding: "12px 16px",
                borderRadius: "8px",
                marginBottom: "20px"
              }}>
                ⚠️ {error}
              </div>
            )}

            <form onSubmit={handleSubmit}>

              {/* TITLE */}
              <div style={{ marginBottom: "20px" }}>
                <label style={{ fontWeight: 600 }}>Article Title *</label>
                <input
                  type="text"
                  name="title"
                  value={formData.title}
                  onChange={handleChange}
                  required
                  style={{
                    width: "100%",
                    padding: "12px",
                    borderRadius: "10px",
                    border: "1px solid #ddd",
                    marginTop: "8px"
                  }}
                />
              </div>

              {/* ROW */}
              <div style={{
                display: "grid",
                gridTemplateColumns: "1fr 1fr",
                gap: "20px",
                marginBottom: "20px"
              }}>
                <div>
                  <label style={{ fontWeight: 600 }}>Category *</label>
                  <select
                    name="category"
                    value={formData.category}
                    onChange={handleChange}
                    style={{
                      width: "100%",
                      padding: "12px",
                      borderRadius: "10px",
                      border: "1px solid #ddd",
                      marginTop: "8px"
                    }}
                  >
                    {CATEGORIES.map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label style={{ fontWeight: 600 }}>Tags</label>
                  <input
                    type="text"
                    name="tags"
                    value={formData.tags}
                    onChange={handleChange}
                    style={{
                      width: "100%",
                      padding: "12px",
                      borderRadius: "10px",
                      border: "1px solid #ddd",
                      marginTop: "8px"
                    }}
                  />
                </div>
              </div>

              {/* COVER */}
              <div style={{ marginBottom: "20px" }}>
                <label style={{ fontWeight: 600 }}>Cover Image URL</label>
                <input
                  type="url"
                  name="coverImageUrl"
                  value={formData.coverImageUrl}
                  onChange={handleChange}
                  style={{
                    width: "100%",
                    padding: "12px",
                    borderRadius: "10px",
                    border: "1px solid #ddd",
                    marginTop: "8px"
                  }}
                />
              </div>

              {/* EDITOR */}
              <div style={{ marginBottom: "20px" }}>
                <label style={{ fontWeight: 600 }}>Content *</label>
                <div style={{ marginTop: "8px" }}>
                  <ReactQuill
                    theme="snow"
                    value={formData.content}
                    onChange={handleContentChange}
                    modules={modules}
                  />
                </div>
              </div>

              {/* BUTTONS */}
              <div style={{ display: "flex", gap: "12px" }}>
                <button
                  type="button"
                  onClick={() => navigate(`/articles/${id}`)}
                  style={{
                    padding: "10px 16px",
                    borderRadius: "10px",
                    border: "1px solid #ddd",
                    background: "#f3f4f6"
                  }}
                >
                  ✕ Cancel
                </button>

                <button
                  type="submit"
                  disabled={loading}
                  style={{
                    flex: 1,
                    padding: "10px 16px",
                    borderRadius: "10px",
                    border: "none",
                    background: "#16a34a",
                    color: "white",
                    fontWeight: 600
                  }}
                >
                  {loading ? '⏳ Saving...' : '💾 Save Changes'}
                </button>
              </div>

            </form>
          </div>

          {/* RIGHT SIDE AI PANEL */}
          <div style={{
            position: "sticky",
            top: "90px",
            height: "fit-content",
            border: "1px solid #e5e7eb",
            borderRadius: "16px",
            padding: "20px"
          }}>
            <h3>🤖 AI Assist</h3>
            <p style={{ fontSize: "0.85rem", color: "#666" }}>
              Enhance your writing with AI
            </p>
          </div>

        </div>
      </div>
    </div>
  )
}

export default EditArticle