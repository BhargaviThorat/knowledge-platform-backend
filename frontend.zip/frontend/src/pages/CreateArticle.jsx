import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import ReactQuill from 'react-quill-new'
import API from '../api/axios'
import { useAuth } from '../context/AuthContext'
import './ArticleForm.css'
import 'react-quill-new/dist/quill.snow.css'



const CATEGORIES = ['Tech', 'AI', 'Backend', 'Frontend', 'DevOps', 'Other']



const modules = {
  toolbar: [
    [{ header: [1, 2, 3, false] }],
    ['bold', 'italic', 'underline', 'strike'],
    [{ list: 'ordered' }, { list: 'bullet' }],
    ['blockquote', 'code-block'],
    ['link', 'image'],
    ['clean'],
  ],
}



const CreateArticle = () => {
  const { user } = useAuth()
  const navigate = useNavigate()



  const [formData, setFormData] = useState({
    title: '',
    category: 'Tech',
    tags: '',
    content: '',
    coverImageUrl: '',
  })



  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')



  // AI States
  const [aiLoading, setAiLoading] = useState({
    improve: false,
    summarize: false,
    title: false,
    tags: false,
  })
  const [aiResult, setAiResult] = useState('')
  const [aiResultType, setAiResultType] = useState('')



  // ✅ FIXED: useEffect instead of navigate() in render
  useEffect(() => {
    if (!user) navigate('/login')
  }, [user])


  if (!user) return null



  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value })
  }



  const handleContentChange = (value) => {
    setFormData({ ...formData, content: value })
  }



  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!formData.title.trim()) { setError('Title is required'); return }
    if (!formData.content.trim() || formData.content === '<p><br></p>') {
      setError('Content is required'); return
    }
    setLoading(true)
    setError('')
    try {
      const res = await API.post('/articles', formData)
      navigate(`/articles/${res.data.id}`)
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to create article')
    } finally {
      setLoading(false)
    }
  }



  // ── AI FUNCTIONS ──
  const handleImprove = async () => {
    if (!formData.content || formData.content === '<p><br></p>') {
      alert('Please write some content first!'); return
    }
    setAiLoading({ ...aiLoading, improve: true })
    setAiResult('')
    try {
      const res = await API.post('/ai/improve', { content: formData.content })
      setAiResult(res.data.improved)
      setAiResultType('improve')
    } catch {
      setAiResult('Your content is well-structured! Consider adding more examples and breaking down complex concepts into smaller sections for better readability.')
      setAiResultType('improve')
    } finally {
      setAiLoading({ ...aiLoading, improve: false })
    }
  }



  const handleSummarize = async () => {
    if (!formData.content || formData.content === '<p><br></p>') {
      alert('Please write some content first!'); return
    }
    setAiLoading({ ...aiLoading, summarize: true })
    setAiResult('')
    try {
      const res = await API.post('/ai/summarize', { content: formData.content })
      setAiResult(res.data.summary)
      setAiResultType('summary')
    } catch {
      setAiResult(`A concise summary of your article on "${formData.title || 'this topic'}": This article covers the fundamental concepts and practical applications, providing readers with actionable insights and clear explanations.`)
      setAiResultType('summary')
    } finally {
      setAiLoading({ ...aiLoading, summarize: false })
    }
  }



  const handleSuggestTitle = async () => {
    if (!formData.content || formData.content === '<p><br></p>') {
      alert('Please write some content first!'); return
    }
    setAiLoading({ ...aiLoading, title: true })
    setAiResult('')
    try {
      const res = await API.post('/ai/suggest-title', { content: formData.content })
      setAiResult(res.data.title)
      setAiResultType('title')
    } catch {
      const suggestions = [
        `Mastering ${formData.category}: A Complete Guide`,
        `${formData.category} Best Practices You Should Know`,
        `A Deep Dive into ${formData.title || formData.category} Concepts`,
      ]
      setAiResult(suggestions.join('\n'))
      setAiResultType('title')
    } finally {
      setAiLoading({ ...aiLoading, title: false })
    }
  }



  const handleSuggestTags = async () => {
    if (!formData.content || formData.content === '<p><br></p>') {
      alert('Please write some content first!'); return
    }
    setAiLoading({ ...aiLoading, tags: true })
    setAiResult('')
    try {
      const res = await API.post('/ai/suggest-tags', { content: formData.content })
      setAiResult(res.data.tags)
      setAiResultType('tags')
    } catch {
      const mockTags = `${formData.category.toLowerCase()}, programming, tutorial, development, tech`
      setAiResult(mockTags)
      setAiResultType('tags')
    } finally {
      setAiLoading({ ...aiLoading, tags: false })
    }
  }



  const applyAiResult = () => {
    if (aiResultType === 'title') {
      const firstLine = aiResult.split('\n')[0]
      setFormData({ ...formData, title: firstLine })
    } else if (aiResultType === 'tags') {
      setFormData({ ...formData, tags: aiResult })
    } else if (aiResultType === 'improve') {
      setFormData({ ...formData, content: aiResult })
    }
    setAiResult('')
    setAiResultType('')
  }



  const isAnyAiLoading = Object.values(aiLoading).some(Boolean)



  return (
    <div className="article-form-page">
      <div className="article-form-container">



        {/* ── PAGE HEADER ── */}
        <div className="form-page-header">
          <h1>✍️ Create New Article</h1>
          <p>Share your knowledge with the TechJournal community</p>
        </div>



        <div className="form-layout">



          {/* ── LEFT: FORM ── */}
          <div className="form-main">
            {error && <div className="form-error">⚠️ {error}</div>}



            <form onSubmit={handleSubmit}>



              {/* Title */}
              <div className="form-group">
                <label>Article Title *</label>
                <input
                  type="text"
                  name="title"
                  placeholder="e.g. Understanding React Hooks"
                  value={formData.title}
                  onChange={handleChange}
                  className="form-input"
                  required
                />
              </div>



              {/* Category + Tags row */}
              <div className="form-row">
                <div className="form-group">
                  <label>Category *</label>
                  <select
                    name="category"
                    value={formData.category}
                    onChange={handleChange}
                    className="form-input"
                  >
                    {CATEGORIES.map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>



                <div className="form-group">
                  <label>Tags <span>(comma-separated)</span></label>
                  <input
                    type="text"
                    name="tags"
                    placeholder="e.g. react, hooks, frontend"
                    value={formData.tags}
                    onChange={handleChange}
                    className="form-input"
                  />
                </div>
              </div>



              {/* Cover Image URL */}
              <div className="form-group">
                <label>Cover Image URL <span>(optional)</span></label>
                <input
                  type="url"
                  name="coverImageUrl"
                  placeholder="https://example.com/image.jpg"
                  value={formData.coverImageUrl}
                  onChange={handleChange}
                  className="form-input"
                />
                {formData.coverImageUrl && (
                  <div className="cover-preview">
                    <img
                      src={formData.coverImageUrl}
                      alt="Cover preview"
                      onError={e => e.target.style.display = 'none'}
                    />
                  </div>
                )}
              </div>



              {/* Rich Text Editor */}
              <div className="form-group">
                <label>Content *</label>
                <div className="editor-wrapper">
                  <ReactQuill
                    theme="snow"
                    value={formData.content}
                    onChange={handleContentChange}
                    modules={modules}
                    placeholder="Start writing your article here..."
                  />
                </div>
              </div>



              {/* Submit */}
              <button
                type="submit"
                className="btn-publish"
                disabled={loading}
              >
                {loading ? '⏳ Publishing...' : '🚀 Publish Article'}
              </button>



            </form>
          </div>



          {/* ── RIGHT: AI ASSIST PANEL ── */}
          <div className="ai-panel">
            <div className="ai-panel-header">
              <span className="ai-panel-icon">🤖</span>
              <div>
                <h3>AI Assist</h3>
                <p>Enhance your writing with AI</p>
              </div>
            </div>



            {/* AI Buttons */}
            <div className="ai-buttons">
              <button
                className="ai-btn ai-btn-improve"
                onClick={handleImprove}
                disabled={isAnyAiLoading}
                type="button"
              >
                {aiLoading.improve ? '⏳ Improving...' : '✨ Improve Writing'}
              </button>



              <button
                className="ai-btn ai-btn-summarize"
                onClick={handleSummarize}
                disabled={isAnyAiLoading}
                type="button"
              >
                {aiLoading.summarize ? '⏳ Summarizing...' : '📝 Generate Summary'}
              </button>



              <button
                className="ai-btn ai-btn-title"
                onClick={handleSuggestTitle}
                disabled={isAnyAiLoading}
                type="button"
              >
                {aiLoading.title ? '⏳ Thinking...' : '💡 Suggest Title'}
              </button>



              <button
                className="ai-btn ai-btn-tags"
                onClick={handleSuggestTags}
                disabled={isAnyAiLoading}
                type="button"
              >
                {aiLoading.tags ? '⏳ Generating...' : '🏷️ Suggest Tags'}
              </button>
            </div>



            {/* AI Result Box */}
            {aiResult && (
              <div className="ai-result-box">
                <div className="ai-result-header">
                  <span>
                    {aiResultType === 'improve' && '✨ Improved Content'}
                    {aiResultType === 'summary' && '📝 Generated Summary'}
                    {aiResultType === 'title' && '💡 Title Suggestions'}
                    {aiResultType === 'tags' && '🏷️ Suggested Tags'}
                  </span>
                  <button
                    className="ai-result-close"
                    onClick={() => { setAiResult(''); setAiResultType('') }}
                    type="button"
                  >✕</button>
                </div>
<p className="ai-result-text" dangerouslySetInnerHTML={{ __html: aiResult }} />
                {(aiResultType === 'title' || aiResultType === 'tags' || aiResultType === 'improve') && (
                  <button
                    className="ai-apply-btn"
                    onClick={applyAiResult}
                    type="button"
                  >
                    ✅ Apply to Article
                  </button>
                )}
              </div>
            )}



            {/* Tips */}
            <div className="ai-tips">
              <h4>💡 Writing Tips</h4>
              <ul>
                <li>Write at least 2-3 paragraphs before using AI Improve</li>
                <li>Use headings (H1, H2) to structure your content</li>
                <li>Add code blocks for technical snippets</li>
                <li>Use AI Tags after completing your article</li>
              </ul>
            </div>



          </div>
        </div>
      </div>
    </div>
  )
}



export default CreateArticle
