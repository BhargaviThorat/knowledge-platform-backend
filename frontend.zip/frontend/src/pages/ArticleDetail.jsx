import { useState, useEffect } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom'
import API from '../api/axios'
import { useAuth } from '../context/AuthContext'
import './ArticleDetail.css'

const ArticleDetail = () => {
  const { id } = useParams()
  const { user } = useAuth()
  const navigate = useNavigate()

  const [article, setArticle] = useState(null)
  const [loading, setLoading] = useState(true)
  const [deleting, setDeleting] = useState(false)
  const [aiSummary, setAiSummary] = useState('')
  const [summaryLoading, setSummaryLoading] = useState(false)

  useEffect(() => {
    fetchArticle()
  }, [id])

  const fetchArticle = async () => {
    try {
      const res = await API.get(`/articles/${id}`)
      setArticle(res.data)
    } catch (err) {
      console.error('Failed to fetch article', err)
    } finally {
      setLoading(false)
    }
  }

  const handleDelete = async () => {
    if (!window.confirm('Are you sure you want to delete this article?')) return
    setDeleting(true)
    try {
      await API.delete(`/articles/${id}`)
      navigate('/')
    } catch (err) {
      alert('Failed to delete article')
    } finally {
      setDeleting(false)
    }
  }

  // ✅ FIXED AI SUMMARY FUNCTION
  const handleAISummary = async () => {
    if (!article?.content) return

    setSummaryLoading(true)

    try {
      const res = await API.post(`/ai/summarize`, {
        content: article.content
      })

      setAiSummary(res.data.result)
    } catch (err) {
      console.error("AI summary failed", err)

      setAiSummary(
        `<p>📝 ${article.content.substring(0, 150)}...</p>`
      )
    } finally {
      setSummaryLoading(false)
    }
  }

  if (loading) return (
    <div className="detail-loading">
      <div className="detail-skeleton-hero" />
      <div className="container">
        <div className="detail-skeleton-title" />
        <div className="detail-skeleton-body" />
      </div>
    </div>
  )

  if (!article) return (
    <div className="detail-not-found">
      <h2>😕 Article not found</h2>
      <Link to="/">← Back to Home</Link>
    </div>
  )

  const isAuthor = user && user.id === article.authorId

  return (
    <div className="article-detail">

      {article.coverImageUrl && (
        <div className="detail-cover">
          <img src={article.coverImageUrl} alt={article.title} />
          <div className="detail-cover-overlay" />
        </div>
      )}

      <div className="container">
        <div className="detail-layout">

          <div className="detail-main">

            <Link to="/" className="detail-back">← Back to Articles</Link>

            <div className="detail-header">
              <span className="detail-category">{article.category}</span>
              <h1 className="detail-title">{article.title}</h1>

              <div className="detail-meta">
                <div className="detail-author-info">
                  <div className="detail-avatar">
                    {article.authorName?.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <span className="detail-author-name">{article.authorName}</span>
                    <span className="detail-dates">
                      Published {new Date(article.createdAt).toLocaleDateString('en-IN')}
                      {article.updatedAt !== article.createdAt && (
                        <span> · Updated {new Date(article.updatedAt).toLocaleDateString('en-IN')}</span>
                      )}
                    </span>
                  </div>
                </div>

                {isAuthor && (
                  <div className="detail-actions">
                    <Link to={`/edit/${article.id}`} className="btn-edit">✏️ Edit</Link>
                    <button
                      onClick={handleDelete}
                      className="btn-delete"
                      disabled={deleting}
                    >
                      {deleting ? '⏳' : '🗑️'} Delete
                    </button>
                  </div>
                )}
              </div>

              <div className="detail-tags">
                {article.tags?.split(',').map(tag => (
                  <span key={tag} className="detail-tag">#{tag.trim()}</span>
                ))}
              </div>
            </div>

            {/* ✅ FIXED AI SUMMARY SECTION */}
            <div className="ai-summary-box">
              <div className="ai-summary-header">
                <span className="ai-badge">🤖 AI Summary</span>
                {!aiSummary && (
                  <button
                    className="btn-generate-summary"
                    onClick={handleAISummary}
                    disabled={summaryLoading}
                  >
                    {summaryLoading ? '⏳ Generating...' : '✨ Generate Summary'}
                  </button>
                )}
              </div>

              {aiSummary && (
                <div
                  className="ai-summary-text"
                  dangerouslySetInnerHTML={{ __html: aiSummary }}
                />
              )}

              {!aiSummary && (
                <p className="ai-summary-placeholder">
                  Click "Generate Summary" to get an AI-powered summary of this article.
                </p>
              )}
            </div>

            <div
              className="detail-content ql-editor"
              dangerouslySetInnerHTML={{ __html: article.content }}
            />

          </div>

          <div className="detail-sidebar">
            <div className="sidebar-card">
              <h4>📋 Article Info</h4>
              <div className="sidebar-info-row">
                <span>Category</span>
                <span className="sidebar-category">{article.category}</span>
              </div>
              <div className="sidebar-info-row">
                <span>Author</span>
                <span>{article.authorName}</span>
              </div>
              <div className="sidebar-info-row">
                <span>Published</span>
                <span>{new Date(article.createdAt).toLocaleDateString()}</span>
              </div>
            </div>

            {article.tags && (
              <div className="sidebar-card">
                <h4>🏷️ Tags</h4>
                <div className="sidebar-tags">
                  {article.tags.split(',').map(tag => (
                    <span key={tag} className="sidebar-tag">#{tag.trim()}</span>
                  ))}
                </div>
              </div>
            )}

            <Link to="/" className="sidebar-home-btn">🏠 Back to Home</Link>
          </div>

        </div>
      </div>
    </div>
  )
}

export default ArticleDetail