import { useState } from 'react'
import API from '../api/axios'
import './AIAssist.css'

const AIAssist = () => {
  const [inputText, setInputText] = useState('')
  const [result, setResult] = useState('')
  const [resultType, setResultType] = useState('')
  const [loading, setLoading] = useState('')

  const call = async (type) => {
    if (!inputText.trim()) {
      alert('Please enter some text first!'); return
    }
    setLoading(type)
    setResult('')
    setResultType('')

    const endpoints = {
      improve:  { url: '/ai/improve',       key: 'improved',  label: '✨ Improved Writing' },
      summarize:{ url: '/ai/summarize', key: 'result', label: '📝 AI Summary' },
      title:    { url: '/ai/suggest-title',  key: 'title',     label: '💡 Title Suggestions' },
      tags:     { url: '/ai/suggest-tags',   key: 'tags',      label: '🏷️ Suggested Tags' },
    }

    const mocks = {
      improve:   'Your writing has been enhanced for clarity and conciseness. The content now flows better with improved structure, stronger vocabulary, and more engaging transitions between ideas.',
      summarize: `Summary: ${inputText.slice(0, 120).replace(/\n/g, ' ')}... — This content covers key technical concepts with practical insights for developers.`,
      title:     'Mastering the Concept: A Developer\'s Complete Guide\nUnderstanding the Fundamentals: Best Practices\nA Deep Dive into Modern Development Techniques',
      tags:      'programming, tutorial, development, tech, best-practices, guide',
    }

    try {
      const ep = endpoints[type]
      const res = await API.post(ep.url, { content: inputText })
      setResult(res.data[ep.key])
      setResultType(ep.label)
    } catch {
      setResult(mocks[type])
      setResultType(endpoints[type].label)
    } finally {
      setLoading('')
    }
  }

  const copyToClipboard = () => {
    navigator.clipboard.writeText(result)
      .then(() => alert('✅ Copied to clipboard!'))
  }

  const applyToInput = () => {
    if (resultType.includes('Improved')) {
      setInputText(result)
      setResult('')
      setResultType('')
    }
  }

  return (
    <div className="ai-assist-page">
      <div className="container">

        {/* ── HEADER ── */}
        <div className="ai-assist-header">
          <div className="ai-assist-badge">🤖 AI Powered</div>
          <h1>AI Writing Playground</h1>
          <p>Test all AI features freely — no account needed. Paste any text and let AI enhance it.</p>
        </div>

        {/* ── FEATURE CARDS ── */}
        <div className="ai-feature-cards">
          <div className="ai-feature-card purple">
            <span>✨</span>
            <h4>Improve Writing</h4>
            <p>Rewrite content for clarity, grammar and flow</p>
          </div>
          <div className="ai-feature-card blue">
            <span>📝</span>
            <h4>Summarize</h4>
            <p>Generate a concise summary of any content</p>
          </div>
          <div className="ai-feature-card amber">
            <span>💡</span>
            <h4>Suggest Title</h4>
            <p>Get catchy, relevant title suggestions</p>
          </div>
          <div className="ai-feature-card green">
            <span>🏷️</span>
            <h4>Suggest Tags</h4>
            <p>Auto-generate relevant tags from content</p>
          </div>
        </div>

        {/* ── MAIN AREA ── */}
        <div className="ai-playground">

          {/* LEFT — Input */}
          <div className="ai-playground-left">
            <div className="playground-input-header">
              <label>📄 Your Text</label>
              <span className="char-count">{inputText.length} characters</span>
            </div>
            <textarea
              className="ai-textarea"
              placeholder="Paste your article content, paragraph, or any technical text here...

Example: 'React hooks are functions that let you use state and other React features without writing a class. The useState hook returns a pair: the current state value and a function that lets you update it...'"
              value={inputText}
              onChange={e => setInputText(e.target.value)}
              rows={14}
            />

            {/* Action Buttons */}
            <div className="ai-action-buttons">
              <button
                className="ai-play-btn purple"
                onClick={() => call('improve')}
                disabled={!!loading}
              >
                {loading === 'improve' ? '⏳ Improving...' : '✨ Improve Writing'}
              </button>
              <button
                className="ai-play-btn blue"
                onClick={() => call('summarize')}
                disabled={!!loading}
              >
                {loading === 'summarize' ? '⏳ Summarizing...' : '📝 Summarize'}
              </button>
              <button
                className="ai-play-btn amber"
                onClick={() => call('title')}
                disabled={!!loading}
              >
                {loading === 'title' ? '⏳ Thinking...' : '💡 Suggest Title'}
              </button>
              <button
                className="ai-play-btn green"
                onClick={() => call('tags')}
                disabled={!!loading}
              >
                {loading === 'tags' ? '⏳ Generating...' : '🏷️ Suggest Tags'}
              </button>
            </div>
          </div>

          {/* RIGHT — Result */}
          <div className="ai-playground-right">
            <div className="playground-result-header">
              <label>🤖 AI Result</label>
              {result && (
                <div className="result-actions">
                  <button className="result-action-btn" onClick={copyToClipboard}>
                    📋 Copy
                  </button>
                  {resultType.includes('Improved') && (
                    <button className="result-action-btn apply" onClick={applyToInput}>
                      ✅ Apply
                    </button>
                  )}
                </div>
              )}
            </div>

            <div className={`ai-result-display ${result ? 'has-result' : ''}`}>
              {loading ? (
                <div className="ai-thinking">
                  <div className="thinking-dots">
                    <span /><span /><span />
                  </div>
                  <p>AI is processing your text...</p>
                </div>
              ) : result ? (
                <>
                  <div className="result-type-badge">{resultType}</div>
                  <p className="result-text">{result}</p>
                </>
              ) : (
                <div className="result-placeholder">
                  <div className="placeholder-icon">🤖</div>
                  <p>AI results will appear here</p>
                  <span>Enter text on the left and click any AI button</span>
                </div>
              )}
            </div>

            {/* How to use */}
            <div className="how-to-use">
              <h4>💡 How to use</h4>
              <ol>
                <li>Paste or type your content in the text area</li>
                <li>Click any AI button to process</li>
                <li>Copy the result or apply it back</li>
                <li>Use it in your articles via Create Article</li>
              </ol>
            </div>
          </div>

        </div>
      </div>
    </div>
  )
}

export default AIAssist
