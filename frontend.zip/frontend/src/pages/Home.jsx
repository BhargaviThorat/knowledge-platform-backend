import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import API from '../api/axios'
import ArticleCard from '../components/ArticleCard'
import './Home.css'

const CATEGORIES = ['All', 'Tech', 'AI', 'Backend', 'Frontend', 'DevOps', 'Other']

const Home = () => {
  const [articles, setArticles] = useState([])
  const [filtered, setFiltered] = useState([])
  const [search, setSearch] = useState('')
  const [activeCategory, setActiveCategory] = useState('All')
  const [loading, setLoading] = useState(true)
  const [currentPage, setCurrentPage] = useState(1)
  const articlesPerPage = 6

  useEffect(() => {
    fetchArticles()
  }, [])

  useEffect(() => {
    applyFilters()
  }, [search, activeCategory, articles])

  const fetchArticles = async () => {
    try {
      const res = await API.get('/articles')
      setArticles(res.data)
    } catch (err) {
      console.error('Failed to fetch articles', err)
    } finally {
      setLoading(false)
    }
  }

  const applyFilters = () => {
    let result = [...articles]
    if (activeCategory !== 'All') {
      result = result.filter(a => a.category === activeCategory)
    }
    if (search.trim()) {
      const q = search.toLowerCase()
      result = result.filter(a =>
        a.title?.toLowerCase().includes(q) ||
        a.content?.toLowerCase().includes(q) ||
        a.tags?.toLowerCase().includes(q)
      )
    }
    setFiltered(result)
    setCurrentPage(1)
  }

  // Pagination
  const totalPages = Math.ceil(filtered.length / articlesPerPage)
  const paginated = filtered.slice(
    (currentPage - 1) * articlesPerPage,
    currentPage * articlesPerPage
  )

  const featured = articles[0] || null

  return (
    <div className="home">
      {/* ── HERO ── */}
      <section className="hero">
        <div className="hero-content">
          <h1 className="hero-title">Welcome to <span>TechJournal!</span></h1>
          <p className="hero-subtitle">Share & Discover Technical Articles with AI Assistance.</p>
          <div className="hero-buttons">
            <Link to="/create" className="btn-primary">✍️ Create New Article</Link>
            <Link to="/dashboard" className="btn-secondary">📊 My Dashboard</Link>
          </div>
        </div>
        <div className="hero-illustration">
          <div className="hero-blob">📚</div>
        </div>
      </section>

      <div className="home-body container">

        {/* ── SEARCH + FILTER ── */}
        <div className="search-filter-bar">
          <input
            type="text"
            className="search-input"
            placeholder="🔍 Search articles by title, content or tags..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>

        <div className="category-pills">
          {CATEGORIES.map(cat => (
            <button
              key={cat}
              className={`pill ${activeCategory === cat ? 'pill-active' : ''}`}
              onClick={() => setActiveCategory(cat)}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* ── FEATURED ARTICLE ── */}
        {featured && activeCategory === 'All' && !search && (
          <div className="featured-section">
            <h2 className="section-title">⭐ Featured Article</h2>
            <Link to={`/articles/${featured.id}`} className="featured-card">
              <div className="featured-info">
                <span className="featured-category">{featured.category}</span>
                <h3 className="featured-title">{featured.title}</h3>
                <p className="featured-summary">{featured.summary || featured.content?.slice(0, 150) + '...'}</p>
                <div className="featured-meta">
                  <span>👤 {featured.authorName}</span>
                  <span>📅 {new Date(featured.createdAt).toLocaleDateString()}</span>
                </div>
                <div className="featured-tags">
                  {featured.tags?.split(',').map(tag => (
                    <span key={tag} className="tag">#{tag.trim()}</span>
                  ))}
                </div>
              </div>
              {featured.coverImageUrl && (
                <div className="featured-image">
                  <img src={featured.coverImageUrl} alt={featured.title} />
                </div>
              )}
            </Link>
          </div>
        )}

        {/* ── RECENT ARTICLES ── */}
        <div className="recent-section">
          <div className="section-header">
            <h2 className="section-title">📰 Recent Articles</h2>
            <span className="article-count">{filtered.length} articles</span>
          </div>

          {loading ? (
            <div className="loading-grid">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="skeleton-card" />
              ))}
            </div>
          ) : paginated.length === 0 ? (
            <div className="empty-state">
              <p>😕 No articles found. Try a different search or category!</p>
            </div>
          ) : (
            <div className="articles-grid">
              {paginated.map(article => (
                <ArticleCard key={article.id} article={article} />
              ))}
            </div>
          )}
        </div>

        {/* ── PAGINATION ── */}
        {totalPages > 1 && (
          <div className="pagination">
            <button
              className="page-btn"
              disabled={currentPage === 1}
              onClick={() => setCurrentPage(p => p - 1)}
            >
              ← Prev
            </button>
            {[...Array(totalPages)].map((_, i) => (
              <button
                key={i}
                className={`page-btn ${currentPage === i + 1 ? 'page-active' : ''}`}
                onClick={() => setCurrentPage(i + 1)}
              >
                {i + 1}
              </button>
            ))}
            <button
              className="page-btn"
              disabled={currentPage === totalPages}
              onClick={() => setCurrentPage(p => p + 1)}
            >
              Next →
            </button>
          </div>
        )}

      </div>
    </div>
  )
}

export default Home
