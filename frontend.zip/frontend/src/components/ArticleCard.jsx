import { Link } from 'react-router-dom'
import './ArticleCard.css'

const CATEGORY_COLORS = {
  Tech:     { bg: '#dbeafe', color: '#1d4ed8' },
  AI:       { bg: '#ede9fe', color: '#7c3aed' },
  Backend:  { bg: '#dcfce7', color: '#16a34a' },
  Frontend: { bg: '#ffedd5', color: '#ea580c' },
  DevOps:   { bg: '#fef9c3', color: '#ca8a04' },
  Other:    { bg: '#f1f5f9', color: '#475569' },
}

const ArticleCard = ({ article }) => {
  const categoryStyle = CATEGORY_COLORS[article.category] || CATEGORY_COLORS['Other']

  return (
    <Link to={`/articles/${article.id}`} className="article-card">

      {/* Cover Image */}
      {article.coverImageUrl && (
        <div className="card-image">
          <img src={article.coverImageUrl} alt={article.title} />
        </div>
      )}

      <div className="card-body">
        {/* Category Badge */}
        <span
          className="card-category"
          style={{ backgroundColor: categoryStyle.bg, color: categoryStyle.color }}
        >
          {article.category}
        </span>

        {/* Title */}
        <h3 className="card-title">{article.title}</h3>

        {/* Summary */}
        <p className="card-summary">
          {article.summary || article.content?.replace(/<[^>]+>/g, '').slice(0, 120) + '...'}
        </p>

        {/* Tags */}
        <div className="card-tags">
          {article.tags?.split(',').slice(0, 3).map(tag => (
            <span key={tag} className="card-tag">#{tag.trim()}</span>
          ))}
        </div>

        {/* Footer */}
        <div className="card-footer">
          <span className="card-author">👤 {article.authorName}</span>
          <span className="card-date">
            {new Date(article.createdAt).toLocaleDateString('en-IN', {
              day: 'numeric', month: 'short', year: 'numeric'
            })}
          </span>
        </div>
      </div>

    </Link>
  )
}

export default ArticleCard
