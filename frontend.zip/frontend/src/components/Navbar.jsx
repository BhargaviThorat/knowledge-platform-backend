import { Link, useNavigate, useLocation } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { FiZap } from 'react-icons/fi'
import './Navbar.css'

const Navbar = () => {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()

  const handleLogout = () => {
    logout()
    navigate('/')
  }

  const isActive = (path) => location.pathname === path

  return (
    <nav className="navbar">
      <div className="navbar-container">

        {/* LEFT — Logo */}
        <Link to="/" className="navbar-logo">
          <FiZap className="logo-icon" />
          <span>TechJournal</span>
        </Link>

        {/* CENTER — Nav Links */}
        <div className="navbar-links">
          <Link to="/" className={isActive('/') ? 'nav-link active' : 'nav-link'}>
            Home
          </Link>
          {user && (
            <Link to="/create" className={isActive('/create') ? 'nav-link active' : 'nav-link'}>
              Create Article
            </Link>
          )}
          {user && (
            <Link to="/dashboard" className={isActive('/dashboard') ? 'nav-link active' : 'nav-link'}>
              My Articles
            </Link>
          )}
          <Link to="/ai-assist" className={isActive('/ai-assist') ? 'nav-link active ai-link' : 'nav-link ai-link'}>
            ✨ AI Assist
          </Link>
        </div>

        {/* RIGHT — Auth Buttons */}
        <div className="navbar-auth">
          {user ? (
            <>
              <span className="navbar-username">👋 {user.username}</span>
              <button onClick={handleLogout} className="btn-logout">
                Logout
              </button>
            </>
          ) : (
            <>
              <Link to="/login" className="btn-login">Login</Link>
              <Link to="/signup" className="btn-signup">Signup</Link>
            </>
          )}
        </div>

      </div>
    </nav>
  )
}

export default Navbar
