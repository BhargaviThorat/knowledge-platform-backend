import { createContext, useContext, useState } from 'react'

const AuthContext = createContext()

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => {
    const stored = localStorage.getItem('user')
    return stored ? JSON.parse(stored) : null
  })

  const login = (userData) => {
  // userData = { id, token, username, email }
  const userToStore = {
    id:       userData.id,
    token:    userData.token,
    username: userData.username,
    email:    userData.email,
  }
  localStorage.setItem('token', userData.token)
  localStorage.setItem('user', JSON.stringify(userToStore))
  setUser(userToStore)
}


  const logout = () => {
    localStorage.removeItem('token')
    localStorage.removeItem('user')
    setUser(null)
  }

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => useContext(AuthContext)
