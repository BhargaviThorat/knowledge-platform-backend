import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider } from './context/AuthContext'
import Navbar from './components/Navbar'
import AIAssist from './pages/AIAssist'
import Home from './pages/Home'
import Login from './pages/Login'
import Signup from './pages/Signup'
import ArticleDetail from './pages/ArticleDetail'
import CreateArticle from './pages/CreateArticle'
import EditArticle from './pages/EditArticle'
import Dashboard from './pages/Dashboard'

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Navbar />
        <Routes>
          <Route path="/"             element={<Home />} />
          <Route path="/login"        element={<Login />} />
          <Route path="/signup"       element={<Signup />} />
          <Route path="/articles/:id" element={<ArticleDetail />} />
          <Route path="/create"       element={<CreateArticle />} />
          <Route path="/edit/:id"     element={<EditArticle />} />
          <Route path="/dashboard"    element={<Dashboard />} />
          <Route path="/ai-assist" element={<AIAssist />} />
          <Route path="*"             element={<Navigate to="/" />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  )
}

export default App
